<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
ini_set('display_errors', '1');
error_reporting(E_ALL);

require_once 'auth.php';
require_once 'koneksi.php';

$message = '';

// Handling Tambah / Edit Wali Kelas
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = $_POST['id'] ?? '';
    $kelas_id = intval($_POST['kelas_id'] ?? 0);
    $guru_id = intval($_POST['guru_id'] ?? 0);

    if ($kelas_id > 0 && $guru_id > 0) {
        if ($action === 'tambah') {
            // Cek apakah kelas sudah punya wali
            $check = $koneksi->query("SELECT id FROM t_wali_kelas WHERE kelas_id = $kelas_id");
            if ($check && $check->num_rows > 0) {
                $message = "Kelas ini sudah memiliki wali kelas!";
            } else {
                $stmt = $koneksi->prepare("INSERT INTO t_wali_kelas (kelas_id, guru_id) VALUES (?, ?)");
                $stmt->bind_param("ii", $kelas_id, $guru_id);
                if ($stmt->execute()) {
                    $message = "Wali kelas berhasil ditambahkan.";
                } else {
                    $message = "Gagal menambahkan wali kelas: " . $stmt->error;
                }
                $stmt->close();
            }
        } elseif ($action === 'edit' && !empty($id)) {
            $stmt = $koneksi->prepare("UPDATE t_wali_kelas SET kelas_id=?, guru_id=? WHERE id=?");
            $stmt->bind_param("iii", $kelas_id, $guru_id, $id);
            if ($stmt->execute()) {
                $message = "Wali kelas berhasil diperbarui.";
            } else {
                $message = "Gagal memperbarui wali kelas: " . $stmt->error;
            }
            $stmt->close();
        }
    } else {
        $message = "Silakan pilih kelas dan guru dengan benar!";
    }
}

// Handling Hapus Wali Kelas
if (isset($_GET['hapus'])) {
    $id_hapus = intval($_GET['hapus']);
    $stmt = $koneksi->prepare("DELETE FROM t_wali_kelas WHERE id=?");
    $stmt->bind_param("i", $id_hapus);
    if ($stmt->execute()) {
        $message = "Wali kelas berhasil dihapus.";
    } else {
        $message = "Gagal menghapus wali kelas: " . $stmt->error;
    }
    $stmt->close();
}

// Handling Mode Edit
$edit_data = null;
if (isset($_GET['edit'])) {
    $id_edit = intval($_GET['edit']);
    $stmt = $koneksi->prepare("SELECT * FROM t_wali_kelas WHERE id=?");
    $stmt->bind_param("i", $id_edit);
    $stmt->execute();
    $edit_data = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

// Fetch Master Kelas & Master Guru untuk Option Dropdown
$list_kelas = $koneksi->query("SELECT * FROM t_kelas ORDER BY nama ASC");
$list_guru = $koneksi->query("SELECT * FROM t_guru WHERE status_aktif = 1 ORDER BY nama ASC");

// Fetch Data List Wali Kelas dengan JOIN t_kelas dan t_guru
$sql_wali = "SELECT w.id, k.nama AS nama_kelas, g.nip, g.nama AS nama_guru 
            FROM t_wali_kelas w
            JOIN t_kelas k ON w.kelas_id = k.id
            JOIN t_guru g ON w.guru_id = g.id
            ORDER BY k.nama ASC";
$result_wali = $koneksi->query($sql_wali);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Wali Kelas - Sistem Pelanggaran</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body { background-color: #f8f9fa; }
        .sidebar { min-height: 100vh; background-color: #212529; color: #fff; }
        .sidebar a { color: #cfd2d6; text-decoration: none; }
        .sidebar a:hover, .sidebar .active { color: #fff; background-color: #007bff; border-radius: 4px; }
        .sidebar-brand { font-size: 0.95rem; font-weight: bold; line-height: 1.3; color: #fff; word-break: break-word; }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">
        <!-- SIDEBAR -->
        <nav class="col-md-3 col-lg-2 d-md-block sidebar p-3">
            <div class="mb-4 pb-2 border-bottom border-secondary">
                <span class="text-muted small d-block">Developer / Admin:</span>
                <span class="sidebar-brand text-primary">AZRIL AKBAR FAWZI ABDILLAH</span>
            </div>
            <ul class="nav flex-column">
                <li class="nav-item mb-2"><a href="dashboard.php" class="nav-link p-2">Dashboard</a></li>
                <li class="nav-item mb-2"><a href="siswa.php" class="nav-link p-2">Data Siswa</a></li>
                <li class="nav-item mb-2"><a href="guru.php" class="nav-link p-2">Data Guru</a></li>
                <li class="nav-item mb-2"><a href="kelas.php" class="nav-link p-2">Kelas</a></li>
                <li class="nav-item mb-2"><a href="wali_kelas.php" class="nav-link active p-2">Wali Kelas</a></li>
                <li class="nav-item mb-2"><a href="laporan.php" class="nav-link p-2">Laporan</a></li>
                <li class="nav-item mb-2"><a href="about.php" class="nav-link p-2">About Me</a></li>
            </ul>
            <hr class="bg-secondary">
            <ul class="nav flex-column">
                <li class="nav-item"><a href="logout.php" class="nav-link text-danger p-2">Logout</a></li>
            </ul>
        </nav>

        <!-- KONTEN UTAMA -->
        <main class="col-md-9 ml-sm-auto col-lg-10 px-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
                <h1 class="h2">Kelola Wali Kelas</h1>
            </div>
            <p class="text-muted">Atur guru yang menjadi wali untuk setiap kelas aktif. Satu kelas memiliki satu wali kelas.</p>

            <!-- PESAN NOTIFIKASI -->
            <?php if (!empty($message)): ?>
                <div class="alert alert-info alert-dismissible fade show" role="alert">
                    <?= htmlspecialchars($message); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>

            <!-- FORM TAMBAH / EDIT WALI KELAS -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><?= $edit_data ? 'Edit Wali Kelas' : 'Tambah Wali Kelas Baru'; ?></h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="wali_kelas.php">
                        <input type="hidden" name="action" value="<?= $edit_data ? 'edit' : 'tambah'; ?>">
                        <?php if ($edit_data): ?>
                            <input type="hidden" name="id" value="<?= $edit_data['id']; ?>">
                        <?php endif; ?>

                        <div class="form-row">
                            <div class="col-md-5 mb-3">
                                <label for="kelas_id">Kelas</label>
                                <select id="kelas_id" name="kelas_id" class="form-control" required>
                                    <option value="">-- Pilih Kelas --</option>
                                    <?php if ($list_kelas): ?>
                                        <?php while ($k = $list_kelas->fetch_assoc()): ?>
                                            <option value="<?= $k['id']; ?>" <?= (isset($edit_data) && $edit_data['kelas_id'] == $k['id']) ? 'selected' : ''; ?>>
                                                <?= htmlspecialchars($k['nama']); ?>
                                            </option>
                                        <?php endwhile; ?>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <div class="col-md-7 mb-3">
                                <label for="guru_id">Nama Wali Kelas (Guru)</label>
                                <select id="guru_id" name="guru_id" class="form-control" required>
                                    <option value="">-- Pilih Guru --</option>
                                    <?php if ($list_guru): ?>
                                        <?php while ($g = $list_guru->fetch_assoc()): ?>
                                            <option value="<?= $g['id']; ?>" <?= (isset($edit_data) && $edit_data['guru_id'] == $g['id']) ? 'selected' : ''; ?>>
                                                <?= htmlspecialchars($g['nama']); ?> (NIP: <?= htmlspecialchars($g['nip']); ?>)
                                            </option>
                                        <?php endwhile; ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary"><?= $edit_data ? 'Simpan Perubahan' : 'Simpan Wali Kelas'; ?></button>
                        <?php if ($edit_data): ?>
                            <a href="wali_kelas.php" class="btn btn-secondary ml-1">Batal Edit</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>

            <!-- TABEL DAFTAR WALI KELAS -->
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Daftar Wali Kelas</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered mb-0">
                            <thead class="thead-dark">
                                <tr>
                                    <th style="width: 5%;">No</th>
                                    <th style="width: 25%;">Kelas</th>
                                    <th style="width: 35%;">Nama Wali Kelas</th>
                                    <th style="width: 20%;">NIP</th>
                                    <th style="width: 15%;">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($result_wali && $result_wali->num_rows > 0): ?>
                                    <?php $no = 1; while ($row = $result_wali->fetch_assoc()): ?>
                                        <tr>
                                            <td><?= $no++; ?></td>
                                            <td><?= htmlspecialchars($row['nama_kelas']); ?></td>
                                            <td><?= htmlspecialchars($row['nama_guru']); ?></td>
                                            <td><?= htmlspecialchars($row['nip']); ?></td>
                                            <td>
                                                <a href="wali_kelas.php?edit=<?= $row['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                                <a href="wali_kelas.php?hapus=<?= $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus wali kelas ini?')">Hapus</a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="text-center py-4 text-muted">Belum ada data wali kelas.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- FOOTER DENGAN NAMA PENGEMBANG -->
            <footer class="mt-5 py-3 text-center text-muted border-top small">
                &copy; 2026 UKK - Sistem Informasi Pelanggaran Siswa | Dikembangkan oleh: <strong>AZRIL AKBAR FAWZI ABDILLAH</strong>
            </footer>
        </main>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
</body>
</html>