<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
ini_set('display_errors', '0');
error_reporting(0);

require_once 'auth.php';
require_once 'koneksi.php';

$message = '';
$edit_data = null;

// Handling Tambah / Edit Kelas
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = $_POST['id'] ?? '';
    $nama = trim($_POST['nama'] ?? '');
    $tingkat = trim($_POST['tingkat'] ?? '');
    $jurusan = trim($_POST['jurusan'] ?? '');
    $status_aktif = isset($_POST['status_aktif']) ? 1 : 0;

    if (!empty($nama)) {
        if ($action === 'tambah') {
            $stmt = $koneksi->prepare("INSERT INTO t_kelas (nama, tingkat, jurusan, status_aktif) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("sssi", $nama, $tingkat, $jurusan, $status_aktif);
            if ($stmt->execute()) {
                $message = "Kelas berhasil ditambahkan.";
            } else {
                $message = "Gagal menambah kelas: " . $stmt->error;
            }
            $stmt->close();
        } elseif ($action === 'edit' && !empty($id)) {
            $stmt = $koneksi->prepare("UPDATE t_kelas SET nama=?, tingkat=?, jurusan=?, status_aktif=? WHERE id=?");
            $stmt->bind_param("sssii", $nama, $tingkat, $jurusan, $status_aktif, $id);
            if ($stmt->execute()) {
                $message = "Kelas berhasil diperbarui.";
            } else {
                $message = "Gagal memperbarui kelas: " . $stmt->error;
            }
            $stmt->close();
        }
    } else {
        $message = "Nama kelas tidak boleh kosong!";
    }
}

// Handling Aksi Nonaktifkan / Aktifkan Status
if (isset($_GET['toggle']) && isset($_GET['id'])) {
    $id_toggle = intval($_GET['id']);
    $q = $koneksi->prepare("SELECT status_aktif FROM t_kelas WHERE id=?");
    $q->bind_param("i", $id_toggle);
    $q->execute();
    $res = $q->get_result()->fetch_assoc();
    if ($res) {
        $new_status = ($res['status_aktif'] == 1) ? 0 : 1;
        $up = $koneksi->prepare("UPDATE t_kelas SET status_aktif=? WHERE id=?");
        $up->bind_param("ii", $new_status, $id_toggle);
        $up->execute();
        $up->close();
    }
    $q->close();
    header("Location: kelas.php");
    exit;
}

// Handling Mode Edit
if (isset($_GET['edit'])) {
    $id_edit = intval($_GET['edit']);
    $stmt = $koneksi->prepare("SELECT * FROM t_kelas WHERE id=?");
    $stmt->bind_param("i", $id_edit);
    $stmt->execute();
    $edit_data = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

// Ambil Daftar Kelas
$result_kelas = $koneksi->query("SELECT * FROM t_kelas ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Kelas - Sistem Pelanggaran</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <style>
        body { background-color: #f8f9fa; }
        .sidebar { min-height: 100vh; background-color: #212529; color: #fff; }
        .sidebar a { color: #cfd2d6; text-decoration: none; }
        .sidebar a:hover, .sidebar .active { color: #fff; background-color: #007bff; border-radius: 4px; }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">
        <!-- SIDEBAR -->
        <nav class="col-md-3 col-lg-2 d-md-block sidebar p-3">
            <h4 class="text-white mb-4">My Website</h4>
            <ul class="nav flex-column">
                <li class="nav-item mb-2"><a href="dashboard.php" class="nav-link p-2">Dashboard</a></li>
                <li class="nav-item mb-2"><a href="siswa.php" class="nav-link p-2">Data Siswa</a></li>
                <li class="nav-item mb-2"><a href="guru.php" class="nav-link p-2">Data Guru</a></li>
                <li class="nav-item mb-2"><a href="kelas.php" class="nav-link active p-2">Kelas</a></li>
                <li class="nav-item mb-2"><a href="laporan.php" class="nav-link p-2">Laporan</a></li>
                <li class="nav-item mb-2"><a href="about.php" class="nav-link p-2">About Me</a></li>
            </ul>
            <hr class="bg-secondary">
            <ul class="nav flex-column">
                <li class="nav-item"><a href="logout.php" class="nav-link text-danger p-2">Logout</a></li>
            </ul>
        </nav>

        <!-- KONTEN UTAMA -->
        <main class="col-md-9 ml-sm-auto col-lg-10 px-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
                <h1 class="h2">Kelola Kelas</h1>
            </div>

            <?php if (!empty($message)): ?>
                <div class="alert alert-info alert-dismissible fade show" role="alert">
                    <?= htmlspecialchars($message); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>

            <!-- FORM TAMBAH / EDIT KELAS -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><?= $edit_data ? 'Edit Data Kelas' : 'Tambah Kelas Baru'; ?></h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="kelas.php">
                        <input type="hidden" name="action" value="<?= $edit_data ? 'edit' : 'tambah'; ?>">
                        <?php if ($edit_data): ?>
                            <input type="hidden" name="id" value="<?= $edit_data['id']; ?>">
                        <?php endif; ?>

                        <div class="form-row">
                            <div class="col-md-4 mb-3">
                                <label for="nama">Nama Kelas</label>
                                <input type="text" class="form-control" id="nama" name="nama" placeholder="Contoh: 10 AKL 3" value="<?= htmlspecialchars($edit_data['nama'] ?? ''); ?>" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="tingkat">Tingkat</label>
                                <input type="text" class="form-control" id="tingkat" name="tingkat" placeholder="Contoh: 10" value="<?= htmlspecialchars($edit_data['tingkat'] ?? ''); ?>" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="jurusan">Jurusan</label>
                                <input type="text" class="form-control" id="jurusan" name="jurusan" placeholder="Contoh: AKL" value="<?= htmlspecialchars($edit_data['jurusan'] ?? ''); ?>" required>
                            </div>
                            <div class="col-md-2 mb-3 d-flex align-items-center">
                                <div class="form-check mt-4">
                                    <input class="form-check-input" type="checkbox" id="status_aktif" name="status_aktif" value="1" <?= (!isset($edit_data) || ($edit_data['status_aktif'] ?? 1) == 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="status_aktif">Aktif</label>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary"><?= $edit_data ? 'Simpan Perubahan' : 'Tambah Kelas'; ?></button>
                        <?php if ($edit_data): ?>
                            <a href="kelas.php" class="btn btn-secondary ml-1">Batal</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>

            <!-- TABEL DAFTAR KELAS -->
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Daftar Kelas</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered mb-0">
                            <thead class="thead-dark">
                                <tr>
                                    <th style="width: 8%;">No</th>
                                    <th style="width: 32%;">Nama Kelas</th>
                                    <th style="width: 15%;">Tingkat</th>
                                    <th style="width: 20%;">Jurusan</th>
                                    <th style="width: 10%;">Status</th>
                                    <th style="width: 15%;">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($result_kelas && $result_kelas->num_rows > 0): ?>
                                    <?php $no = 1; while ($row = $result_kelas->fetch_assoc()): ?>
                                        <tr>
                                            <td><?= $no++; ?></td>
                                            <td><?= htmlspecialchars($row['nama']); ?></td>
                                            <td><?= htmlspecialchars($row['tingkat']); ?></td>
                                            <td><?= htmlspecialchars($row['jurusan']); ?></td>
                                            <td>
                                                <span class="badge <?= ($row['status_aktif'] == 1) ? 'badge-success' : 'badge-secondary'; ?>">
                                                    <?= ($row['status_aktif'] == 1) ? 'Aktif' : 'Non-Aktif'; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="kelas.php?edit=<?= $row['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                                <a href="kelas.php?toggle=true&id=<?= $row['id']; ?>" class="btn btn-sm <?= ($row['status_aktif'] == 1) ? 'btn-secondary' : 'btn-success'; ?>">
                                                    <?= ($row['status_aktif'] == 1) ? 'Nonaktifkan' : 'Aktifkan'; ?>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-3">Belum ada data kelas.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </main>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
</body>
</html>
