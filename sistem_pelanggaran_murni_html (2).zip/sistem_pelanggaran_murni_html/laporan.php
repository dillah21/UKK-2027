<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
ini_set('display_errors', '1');
error_reporting(E_ALL);

require_once 'auth.php';
require_once 'koneksi.php';

// Ambil data kelas untuk pilihan filter (jika diperlukan)
$query_kelas = $koneksi->query("SELECT * FROM t_kelas WHERE status_aktif = 1 ORDER BY nama ASC");

// Ambil parameter filter tanggal
$dari_tanggal = $_GET['dari_tanggal'] ?? '';
$sampai_tanggal = $_GET['sampai_tanggal'] ?? '';

// Query laporan pelanggaran yang terhubung ke data siswa
$sql = "SELECT r.*, s.nis, s.nama AS nama_siswa 
        FROM t_riwayat_pelanggaran r 
        JOIN t_siswa s ON r.id_siswa = s.id WHERE 1=1";

$params = [];
$types = "";

if (!empty($dari_tanggal) && !empty($sampai_tanggal)) {
    $sql .= " AND r.tanggal BETWEEN ? AND ?";
    $params[] = $dari_tanggal;
    $params[] = $sampai_tanggal;
    $types .= "ss";
}

$sql .= " ORDER BY r.tanggal DESC";

if (!empty($params)) {
    $stmt = $koneksi->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
} else {
    $result = $koneksi->query($sql);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Pelanggaran Siswa - Sistem Pelanggaran</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body { background-color: #f8f9fa; }
        .sidebar { min-height: 100vh; background-color: #212529; color: #fff; }
        .sidebar a { color: #cfd2d6; text-decoration: none; }
        .sidebar a:hover, .sidebar .active { color: #fff; background-color: #007bff; border-radius: 4px; }
        @media print {
            .sidebar, .card-filter, .btn-print, .no-print { display: none !important; }
            main { width: 100% !important; margin: 0 !important; padding: 0 !important; }
        }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">
        <!-- SIDEBAR -->
        <nav class="col-md-3 col-lg-2 d-md-block sidebar p-3 no-print">
            <h4 class="text-white mb-4">My Website</h4>
            <ul class="nav flex-column">
                <li class="nav-item mb-2"><a href="dashboard.php" class="nav-link p-2">Dashboard</a></li>
                <li class="nav-item mb-2"><a href="siswa.php" class="nav-link p-2">Data Siswa</a></li>
                <li class="nav-item mb-2"><a href="guru.php" class="nav-link p-2">Data Guru</a></li>
                <li class="nav-item mb-2"><a href="kelas.php" class="nav-link p-2">Kelas</a></li>
                <li class="nav-item mb-2"><a href="laporan.php" class="nav-link active p-2">Laporan</a></li>
                <li class="nav-item mb-2"><a href="about.php" class="nav-link p-2">About Me</a></li>
            </ul>
            <hr class="bg-secondary">
            <ul class="nav flex-column">
                <li class="nav-item"><a href="logout.php" class="nav-link text-danger p-2">Logout</a></li>
            </ul>
        </nav>

        <!-- KONTEN UTAMA -->
        <main class="col-md-9 ml-sm-auto col-lg-10 px-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
                <h1 class="h2">Laporan Pelanggaran Siswa</h1>
                <div>
                    <button onclick="window.print()" class="btn btn-secondary btn-sm"><i class="fas fa-print"></i> Cetak Laporan</button>
                </div>
            </div>

            <p class="text-muted">Saring, cetak, atau unduh rekapitulasi data pelanggaran siswa.</p>

            <!-- CARD FILTER -->
            <div class="card shadow-sm mb-4 card-filter">
                <div class="card-body bg-light">
                    <form method="GET" action="laporan.php" class="form-row align-items-center">
                        <div class="col-md-4 mb-2">
                            <label class="small mb-1">Dari Tanggal</label>
                            <input type="date" class="form-control form-control-sm" name="dari_tanggal" value="<?= htmlspecialchars($dari_tanggal); ?>">
                        </div>
                        <div class="col-md-4 mb-2">
                            <label class="small mb-1">Sampai Tanggal</label>
                            <input type="date" class="form-control form-control-sm" name="sampai_tanggal" value="<?= htmlspecialchars($sampai_tanggal); ?>">
                        </div>
                        <div class="col-md-4 mb-2 d-flex align-items-end mt-4">
                            <button type="submit" class="btn btn-primary btn-sm mr-2"><i class="fas fa-filter"></i> Filter</button>
                            <a href="laporan.php" class="btn btn-outline-secondary btn-sm">Reset</a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- TABEL HASIL LAPORAN -->
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Hasil Laporan Pelanggaran</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered mb-0">
                            <thead class="thead-dark">
                                <tr>
                                    <th style="width: 5%;">No</th>
                                    <th style="width: 15%;">Tanggal</th>
                                    <th style="width: 15%;">NIS</th>
                                    <th style="width: 30%;">Nama Siswa</th>
                                    <th style="width: 25%;">Bentuk Pelanggaran</th>
                                    <th style="width: 10%;">Poin</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($result && $result->num_rows > 0): ?>
                                    <?php $no = 1; while ($row = $result->fetch_assoc()): ?>
                                        <tr>
                                            <td><?= $no++; ?></td>
                                            <td><?= htmlspecialchars($row['tanggal']); ?></td>
                                            <td><?= htmlspecialchars($row['nis']); ?></td>
                                            <td><?= htmlspecialchars($row['nama_siswa']); ?></td>
                                            <td><?= htmlspecialchars($row['bentuk_pelanggaran']); ?></td>
                                            <td><span class="badge badge-danger"><?= htmlspecialchars($row['poin']); ?></span></td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-4 text-muted">Tidak ada data pelanggaran yang sesuai filter.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- FOOTER DENGAN NAMA PENGEMBANG -->
            <footer class="mt-5 py-3 text-center text-muted border-top small">
                &copy; 2026 UKK - Sistem Informasi Pelanggaran Siswa | Dikembangkan oleh: <strong>AZRIL AKBAR FAWZI ABDILLAH</strong>
            </footer>
        </main>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
</body>
</html>