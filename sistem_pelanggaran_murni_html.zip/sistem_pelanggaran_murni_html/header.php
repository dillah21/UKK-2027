<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Pelanggaran Siswa</title>
</head>
<body>

<?php
// Ambil nama file halaman yang sedang dibuka
$current_page = basename($_SERVER['PHP_SELF']);

// Tampilkan menu header HANYA jika BUKAN halaman dashboard.php
if ($current_page !== 'dashboard.php'): 
?>
    <div>
        <h1>Sistem Pelanggaran Siswa</h1>
        <a href="dashboard.php">Dashboard</a> | 
        <a href="siswa.php">Kelola Siswa</a> | 
        <a href="guru.php">Kelola Guru</a> |
        <a href="kelas.php">Kelas</a> | 
        <a href="kelas_siswa.php">Penempatan Siswa</a> | 
        <a href="wali_kelas.php">Wali Kelas</a> | 
        <a href="pelanggaran_kategori.php">Pelanggaran Kategori</a> | 
        <a href="pelanggaran.php">Pelanggaran</a> | 
        <a href="rekap_poin.php">Rekap Poin</a> | 
        <a href="riwayat_pelanggaran.php">Riwayat Pelanggaran</a> | 
        <a href="laporan.php">Laporan</a> | 
        <a href="logout.php">Logout</a>
    </div>
    <hr>
<?php endif; ?>