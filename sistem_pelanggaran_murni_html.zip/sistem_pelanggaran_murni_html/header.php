
<ul class="nav flex-column">

    <!-- MENU DASHBOARD: SEMUA ROLE -->
    <li class="nav-item">
        <a class="nav-link <?= ($current_page === 'dashboard.php') ? 'active' : ''; ?>"
           href="dashboard.php">
            <i class="fas fa-home"></i> Dashboard
        </a>
    </li>

    <?php if ($role === 'siswa'): ?>

        <!-- MENU KHUSUS SISWA -->

        <li class="nav-item">
            <a class="nav-link <?= ($current_page === 'siswa.php') ? 'active' : ''; ?>"
               href="siswa.php">
                <i class="fas fa-user-graduate"></i> Data Siswa
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?= ($current_page === 'prestasi.php') ? 'active' : ''; ?>"
               href="prestasi.php">
                <i class="fas fa-trophy text-warning"></i> Data Prestasi
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?= ($current_page === 'kelas.php') ? 'active' : ''; ?>"
               href="kelas.php">
                <i class="fas fa-school"></i> Kelas
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?= ($current_page === 'wali_kelas.php') ? 'active' : ''; ?>"
               href="wali_kelas.php">
                <i class="fas fa-user-tie"></i> Wali Kelas
            </a>
        </li>

    <?php else: ?>

        <!-- MENU KHUSUS ADMIN -->
        <?php if ($role === 'admin'): ?>

            <li class="nav-item">
                <a class="nav-link <?= ($current_page === 'siswa.php') ? 'active' : ''; ?>"
                   href="siswa.php">
                    <i class="fas fa-user-graduate"></i> Data Siswa
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?= ($current_page === 'guru.php') ? 'active' : ''; ?>"
                   href="guru.php">
                    <i class="fas fa-chalkboard-teacher"></i> Data Guru
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?= ($current_page === 'kelas.php') ? 'active' : ''; ?>"
                   href="kelas.php">
                    <i class="fas fa-school"></i> Kelas
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?= ($current_page === 'wali_kelas.php') ? 'active' : ''; ?>"
                   href="wali_kelas.php">
                    <i class="fas fa-user-tie"></i> Wali Kelas
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?= ($current_page === 'tahun_ajaran.php') ? 'active' : ''; ?>"
                   href="tahun_ajaran.php">
                    <i class="fas fa-calendar-alt"></i> Tahun Ajaran
                </a>
            </li>

        <?php endif; ?>

        <!-- MENU PELANGGARAN: ADMIN DAN GURU -->
        <?php if ($role === 'admin' || $role === 'guru'): ?>

            <li class="nav-item">
                <a class="nav-link <?= ($current_page === 'pelanggaran_kategori.php') ? 'active' : ''; ?>"
                   href="pelanggaran_kategori.php">
                    <i class="fas fa-tags"></i> Kategori Pelanggaran
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?= ($current_page === 'pelanggaran.php') ? 'active' : ''; ?>"
                   href="pelanggaran.php">
                    <i class="fas fa-exclamation-triangle"></i> Data Pelanggaran
                </a>
            </li>

        <?php endif; ?>

        <!-- MENU PRESTASI -->
        <li class="nav-item">
            <a class="nav-link <?= ($current_page === 'prestasi.php') ? 'active' : ''; ?>"
               href="prestasi.php">
                <i class="fas fa-trophy text-warning"></i> Data Prestasi
            </a>
        </li>

        <!-- MENU LAPORAN -->
        <li class="nav-item">
            <a class="nav-link <?= ($current_page === 'laporan.php') ? 'active' : ''; ?>"
               href="laporan.php">
                <i class="fas fa-file-alt"></i> Laporan & Rekap
            </a>
        </li>

        <!-- MENU TENTANG SAYA -->
        <li class="nav-item">
            <a class="nav-link <?= ($current_page === 'about_me.php') ? 'active' : ''; ?>"
               href="about_me.php">
                <i class="fas fa-info-circle"></i> Tentang Saya
            </a>
        </li>

        <!-- MENU PENGATURAN PROFIL -->
        <li class="nav-item">
            <a class="nav-link <?= ($current_page === 'profile.php') ? 'active' : ''; ?>"
               href="profile.php">
                <i class="fas fa-user-cog"></i> Pengaturan Profil
            </a>
        </li>

    <?php endif; ?>

</ul>

<div class="sidebar-divider"></div>

<ul class="nav flex-column mb-2">
    <li class="nav-item">
        <a class="nav-link text-danger"
           href="logout.php"
           onclick="return confirm('Apakah Anda yakin ingin keluar?');">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    </li>
</ul>
