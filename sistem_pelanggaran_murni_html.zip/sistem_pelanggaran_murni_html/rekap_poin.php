<?php
require_once 'auth.php';
require_once 'koneksi.php';

// Handling Pencarian
$search = trim($_GET['search'] ?? '');

// Query Rekap Total Poin per Siswa
$sql = "SELECT s.id, s.nis, s.nama AS nama_siswa, 
               IFNULL(SUM(ps.poin), 0) AS total_poin, 
               COUNT(ps.id) AS total_pelanggaran
        FROM t_siswa s
        LEFT JOIN t_pelanggaran_siswa ps ON s.id = ps.siswa_id";

if (!empty($search)) {
    $sql .= " WHERE s.nama LIKE '%" . $koneksi->real_escape_string($search) . "%' 
               OR s.nis LIKE '%" . $koneksi->real_escape_string($search) . "%'";
}

$sql .= " GROUP BY s.id ORDER BY total_poin DESC, s.nama ASC";
$result = $koneksi->query($sql);

include 'header.php';
?>

<h2>Rekapitulasi Total Poin Siswa</h2>

<!-- Form Pencarian -->
<form method="GET" action="rekap_poin.php">
    <label for="search">Cari Siswa (Nama / NIS):</label>
    <input type="text" id="search" name="search" placeholder="Masukkan Nama atau NIS..." value="<?= htmlspecialchars($search); ?>">
    <button type="submit">Cari</button>
    <?php if (!empty($search)): ?>
        <a href="rekap_poin.php">Reset Filter</a>
    <?php endif; ?>
</form>

<br>

<table border="1" cellpadding="8" cellspacing="0">
    <thead>
        <tr>
            <th>No</th>
            <th>NIS</th>
            <th>Nama Siswa</th>
            <th>Total Pelanggaran</th>
            <th>Total Akumulasi Poin</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result && $result->num_rows > 0): ?>
            <?php $no = 1; while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= htmlspecialchars($row['nis']); ?></td>
                    <td><?= htmlspecialchars($row['nama_siswa']); ?></td>
                    <td align="center"><?= $row['total_pelanggaran']; ?> Kali</td>
                    <td align="center"><b><?= $row['total_poin']; ?> Poin</b></td>
                    <td>
                        <a href="riwayat_pelanggaran.php?siswa_id=<?= $row['id']; ?>">Lihat Riwayat</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="6" align="center">Data rekap poin tidak ditemukan.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<?php include 'footer.php'; ?>