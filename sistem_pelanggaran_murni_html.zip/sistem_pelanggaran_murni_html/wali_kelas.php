<?php
include 'koneksi.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';
    $kelas_id = (int)($_POST['kelas_id'] ?? 0);
    $nama = trim($_POST['nama_wali'] ?? '');
    $nip = trim($_POST['nip'] ?? '');
    if ($aksi === 'simpan' || $aksi === 'ubah') {
        if ($kelas_id < 1 || $nama === '') {
            $error = 'Kelas dan nama wali kelas wajib diisi.';
        } else {
            if ($aksi === 'simpan') {
                $stmt = mysqli_prepare($koneksi, 'INSERT INTO t_wali_kelas (kelas_id, nama_wali, nip) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE nama_wali=VALUES(nama_wali), nip=VALUES(nip)');
                mysqli_stmt_bind_param($stmt, 'iss', $kelas_id, $nama, $nip);
            } else {
                $id = (int)($_POST['id'] ?? 0);
                $stmt = mysqli_prepare($koneksi, 'UPDATE t_wali_kelas SET kelas_id=?, nama_wali=?, nip=? WHERE id=?');
                mysqli_stmt_bind_param($stmt, 'issi', $kelas_id, $nama, $nip, $id);
            }
            if (mysqli_stmt_execute($stmt)) { header('Location: wali_kelas.php?pesan=simpan'); exit; }
            $error = 'Gagal menyimpan data wali kelas. Periksa kembali database.';
        }
    } elseif ($aksi === 'hapus') {
        $id = (int)($_POST['id'] ?? 0);
        $stmt = mysqli_prepare($koneksi, 'DELETE FROM t_wali_kelas WHERE id=?');
        mysqli_stmt_bind_param($stmt, 'i', $id);
        if (mysqli_stmt_execute($stmt)) { header('Location: wali_kelas.php?pesan=hapus'); exit; }
        $error = 'Gagal menghapus data wali kelas.';
    }
}
include 'header.php';
$edit = null;
if (isset($_GET['edit'])) {
    $id_edit = (int)$_GET['edit'];
    $stmt = mysqli_prepare($koneksi, 'SELECT id, kelas_id, nama_wali, nip FROM t_wali_kelas WHERE id=?');
    mysqli_stmt_bind_param($stmt, 'i', $id_edit);
    mysqli_stmt_execute($stmt);
    $edit = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}
$success = '';
if (($_GET['pesan'] ?? '') === 'simpan') $success = 'Data wali kelas berhasil disimpan.';
if (($_GET['pesan'] ?? '') === 'hapus') $success = 'Data wali kelas berhasil dihapus.';
$kelas = mysqli_query($koneksi, 'SELECT id, nama FROM t_kelas WHERE status_aktif=1 ORDER BY nama');
?>
<h3>Kelola Wali Kelas</h3>
<p>Atur guru yang menjadi wali untuk setiap kelas aktif. Satu kelas memiliki satu wali kelas.</p>
<?php if ($error): ?><p style="color:red"><?= htmlspecialchars($error) ?></p><?php endif; ?>
<?php if ($success): ?><p style="color:green"><?= htmlspecialchars($success) ?></p><?php endif; ?>
<form method="post">
    <input type="hidden" name="aksi" value="<?= $edit ? 'ubah' : 'simpan' ?>">
    <?php if ($edit): ?><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>"><?php endif; ?>
    <p><label>Kelas</label><br><select name="kelas_id" required>
    <option value="">-- Pilih Kelas --</option>
    <?php if ($kelas) while ($k = mysqli_fetch_assoc($kelas)): ?>
    <option value="<?= (int)$k['id'] ?>" <?= (int)($edit['kelas_id'] ?? 0) === (int)$k['id'] ? 'selected' : '' ?>><?= htmlspecialchars($k['nama']) ?></option>
    <?php endwhile; ?></select></p>
    <p><label>Nama Wali Kelas</label><br><input type="text" name="nama_wali" maxlength="150" required value="<?= htmlspecialchars($edit['nama_wali'] ?? '') ?>" placeholder="Nama lengkap guru"></p>
    <p><label>NIP (opsional)</label><br><input type="text" name="nip" maxlength="30" value="<?= htmlspecialchars($edit['nip'] ?? '') ?>" placeholder="Nomor Induk Pegawai"></p>
    <button type="submit"><?= $edit ? 'Simpan Perubahan' : 'Simpan Wali Kelas' ?></button>
    <?php if ($edit): ?> <a href="wali_kelas.php">Batal</a><?php endif; ?>
</form>
<h4>Daftar Wali Kelas</h4>
<table border="1" cellpadding="7" cellspacing="0" width="100%">
<thead><tr><th>No</th><th>Kelas</th><th>Nama Wali Kelas</th><th>NIP</th><th>Aksi</th></tr></thead><tbody>
<?php
$result = mysqli_query($koneksi, 'SELECT w.id, w.kelas_id, w.nama_wali, w.nip, k.nama AS nama_kelas FROM t_wali_kelas w INNER JOIN t_kelas k ON k.id=w.kelas_id ORDER BY k.nama');
$no = 1;
if ($result && mysqli_num_rows($result)) {
    while ($row = mysqli_fetch_assoc($result)) {
        $id = (int)$row['id'];
        echo '<tr><td>'.$no++.'</td><td>'.htmlspecialchars($row['nama_kelas']).'</td><td>'.htmlspecialchars($row['nama_wali']).'</td><td>'.htmlspecialchars($row['nip'] ?? '').'</td><td><a href="wali_kelas.php?edit='.$id.'">Edit</a> ';
        echo '<form method="post" style="display:inline" onsubmit="return confirm(\'Hapus penugasan wali kelas ini?\')"><input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="'.$id.'"><button type="submit">Hapus</button></form></td></tr>';
    }
} else echo '<tr><td colspan="5" align="center">Belum ada data wali kelas.</td></tr>';
?>
</tbody></table>
<?php include 'footer.php'; ?>
