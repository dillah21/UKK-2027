<?php
include 'koneksi.php';

$tahun_id = isset($_GET['tahun_ajaran_id']) ? (int)$_GET['tahun_ajaran_id'] : 0;
$kelas_id = isset($_GET['kelas_id']) ? (int)$_GET['kelas_id'] : 0;
$tanggal_mulai = trim($_GET['tanggal_mulai'] ?? '');
$tanggal_selesai = trim($_GET['tanggal_selesai'] ?? '');
$status = trim($_GET['status'] ?? '');

$where = [];
if ($tahun_id > 0) $where[] = 'tahun_ajaran_id = ' . $tahun_id;
if ($kelas_id > 0) $where[] = 'kelas_id = ' . $kelas_id;
if ($tanggal_mulai !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal_mulai)) $where[] = "tanggal >= '" . mysqli_real_escape_string($koneksi, $tanggal_mulai) . "'";
if ($tanggal_selesai !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal_selesai)) $where[] = "tanggal <= '" . mysqli_real_escape_string($koneksi, $tanggal_selesai) . "'";
if (in_array($status, ['Proses', 'Selesai'], true)) $where[] = "status = '" . mysqli_real_escape_string($koneksi, $status) . "'";
$sql = 'SELECT * FROM t_pelanggaran_siswa' . (count($where) ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY tanggal DESC, nama_siswa ASC';
$result = mysqli_query($koneksi, $sql);
$rows = [];
$total_poin = 0;
if ($result) while ($row = mysqli_fetch_assoc($result)) { $rows[] = $row; $total_poin += (int)$row['poin']; }
include 'header.php';
?>
<style>
@media print { .no-print, header, nav { display:none !important; } body { font-size: 12px; } table { width:100%; border-collapse:collapse; } th,td { border:1px solid #333; padding:5px; } }
table { border-collapse:collapse; } th,td { padding:7px; }
</style>
<h3>Laporan Pelanggaran Siswa</h3>
<form method="get" class="no-print" style="border:1px solid #ccc;padding:12px;margin-bottom:16px">
    <p><label>Tahun Ajaran:</label><br><select name="tahun_ajaran_id"><option value="0">Semua Tahun Ajaran</option>
    <?php $ta = mysqli_query($koneksi, 'SELECT id,nama FROM t_tahun_ajaran ORDER BY tanggal_mulai DESC'); if ($ta) while ($t = mysqli_fetch_assoc($ta)): ?>
      <option value="<?= (int)$t['id'] ?>" <?= $tahun_id === (int)$t['id'] ? 'selected' : '' ?>><?= htmlspecialchars($t['nama']) ?></option>
    <?php endwhile; ?></select></p>
    <p><label>Kelas:</label><br><select name="kelas_id"><option value="0">Semua Kelas</option>
    <?php $ks = mysqli_query($koneksi, 'SELECT id,nama FROM t_kelas ORDER BY nama'); if ($ks) while ($k = mysqli_fetch_assoc($ks)): ?>
      <option value="<?= (int)$k['id'] ?>" <?= $kelas_id === (int)$k['id'] ? 'selected' : '' ?>><?= htmlspecialchars($k['nama']) ?></option>
    <?php endwhile; ?></select></p>
    <p><label>Tanggal Mulai:</label><br><input type="date" name="tanggal_mulai" value="<?= htmlspecialchars($tanggal_mulai) ?>"></p>
    <p><label>Tanggal Selesai:</label><br><input type="date" name="tanggal_selesai" value="<?= htmlspecialchars($tanggal_selesai) ?>"></p>
    <p><label>Status Pembinaan:</label><br><select name="status"><option value="">Semua Status</option><option value="Proses" <?= $status === 'Proses' ? 'selected' : '' ?>>Proses</option><option value="Selesai" <?= $status === 'Selesai' ? 'selected' : '' ?>>Selesai</option></select></p>
    <button type="submit">Tampilkan Laporan</button> <a href="laporan.php">Reset</a> <button type="button" onclick="window.print()">Cetak / Simpan PDF</button>
</form>
<h4>Ringkasan</h4>
<p>Jumlah catatan: <strong><?= count($rows) ?></strong> &nbsp; | &nbsp; Total poin pelanggaran: <strong><?= $total_poin ?></strong></p>
<table border="1" cellpadding="5" cellspacing="0" width="100%">
<thead><tr><th>No</th><th>Tanggal</th><th>Nama Siswa</th><th>Kelas</th><th>Pelanggaran</th><th>Guru Pelapor</th><th>Poin</th><th>Status</th><th>Tindakan</th></tr></thead>
<tbody>
<?php if ($rows): foreach ($rows as $i => $r): ?>
<tr><td><?= $i + 1 ?></td><td><?= htmlspecialchars(date('d-m-Y', strtotime($r['tanggal']))) ?></td><td><?= htmlspecialchars($r['nama_siswa']) ?></td><td><?= htmlspecialchars($r['nama_kelas']) ?></td><td><?= htmlspecialchars($r['nama_pelanggaran']) ?></td><td><?= htmlspecialchars($r['nama_guru']) ?></td><td><?= (int)$r['poin'] ?></td><td><?= htmlspecialchars($r['status']) ?></td><td><?= htmlspecialchars($r['tindakan']) ?></td></tr>
<?php endforeach; else: ?><tr><td colspan="9" align="center">Tidak ada data sesuai filter.</td></tr><?php endif; ?>
</tbody></table>
<p class="no-print"><a href="pelanggaran.php">Kembali ke Data Pelanggaran</a></p>
<?php include 'footer.php'; ?>
