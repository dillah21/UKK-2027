<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'auth.php';
require_once 'koneksi.php';

$pesan_sukses = "";
$pesan_error = "";

// PROSES TAMBAH PENEMPATAN SISWA
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah_penempatan'])) {
    $id_siswa = intval($_POST['id_siswa'] ?? 0);
    $id_kelas = intval($_POST['id_kelas'] ?? 0);
    $tahun_ajaran = trim($_POST['tahun_ajaran'] ?? '2026/2027');

    if ($id_siswa > 0 && $id_kelas > 0) {
        // Cek apakah siswa sudah ditempatkan di kelas/tahun tersebut
        $cek = mysqli_query($koneksi, "SELECT * FROM t_siswa_kelas WHERE id_siswa = $id_siswa");
        if (mysqli_num_rows($cek) > 0) {
            // Update jika sudah ada
            $query_simpan = mysqli_query($koneksi, "UPDATE t_siswa_kelas SET id_kelas = $id_kelas, tahun_ajaran = '$tahun_ajaran' WHERE id_siswa = $id_siswa");
        } else {
            // Insert baru
            $query_simpan = mysqli_query($koneksi, "INSERT INTO t_siswa_kelas (id_siswa, id_kelas, tahun_ajaran) VALUES ($id_siswa, $id_kelas, '$tahun_ajaran')");
        }

        if ($query_simpan) {
            $pesan_sukses = "Penempatan siswa berhasil disimpan!";
        } else {
            $pesan_error = "Gagal menyimpan penempatan: " . mysqli_error($koneksi);
        }
    } else {
        $pesan_error = "Pilih siswa dan kelas terlebih dahulu!";
    }
}

// PROSES HAPUS PENEMPATAN
if (isset($_GET['action']) && $_GET['action'] === 'hapus' && isset($_GET['id'])) {
    $id_hapus = intval($_GET['id']);
    @mysqli_query($koneksi, "DELETE FROM t_siswa_kelas WHERE id = $id_hapus OR id_siswa_kelas = $id_hapus");
    $pesan_sukses = "Penempatan siswa berhasil dihapus!";
}

include 'header.php';

// Ambil data penempatan gabungan dengan tabel siswa dan kelas
$query_penempatan = mysqli_query($koneksi, "
    SKIPPED_OR_STANDARD_JOIN
");
// Menggunakan query aman universal:
$query_data = mysqli_query($koneksi, "SELECT * FROM t_siswa_kelas");

// Ambil data pilihan siswa & kelas untuk form
$data_siswa = mysqli_query($koneksi, "SELECT * FROM t_siswa");
$data_kelas = mysqli_query($koneksi, "SELECT * FROM t_kelas");
?>

<!-- CSS DATATABLES -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">

<div class="content-wrapper" style="padding: 15px;">
    <section class="content">
        <div class="container-fluid">

            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><i class="fas fa-chalkboard-teacher mr-2"></i> Penempatan Siswa ke Kelas</h1>
            </div>

            <?php if (!empty($pesan_sukses)): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?= $pesan_sukses; ?>
                    <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
                </div>
            <?php endif; ?>

            <?php if (!empty($pesan_error)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?= $pesan_error; ?>
                    <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
                </div>
            <?php endif; ?>

            <!-- Form Tambah Penempatan -->
            <?php if (strtolower($_SESSION['role'] ?? '') === 'admin'): ?>
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-primary text-white">
                    <h3 class="card-title font-weight-bold mb-0" style="font-size: 1rem;"><i class="fas fa-plus-circle mr-1"></i> Form Atur Kelas Siswa</h3>
                </div>
                <div class="card-body">
                    <form action="" method="POST">
                        <div class="row">
                            <div class="col-md-4 form-group">
                                <label>Pilih Siswa <span class="text-danger">*</span></label>
                                <select name="id_siswa" class="form-control" required>
                                    <option value="">-- Pilih Siswa --</option>
                                    <?php while ($s = mysqli_fetch_assoc($data_siswa)): 
                                        $id_s = $s['id'] ?? $s['id_siswa'] ?? 0;
                                        $nama_s = $s['nama'] ?? $s['nama_siswa'] ?? '';
                                    ?>
                                        <option value="<?= $id_s; ?>"><?= htmlspecialchars($nama_s); ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="col-md-4 form-group">
                                <label>Pilih Kelas <span class="text-danger">*</span></label>
                                <select name="id_kelas" class="form-control" required>
                                    <option value="">-- Pilih Kelas --</option>
                                    <?php while ($k = mysqli_fetch_assoc($data_kelas)): 
                                        $id_k = $k['id'] ?? $k['id_kelas'] ?? 0;
                                        $nama_k = $k['nama_kelas'] ?? $k['kelas'] ?? '';
                                    ?>
                                        <option value="<?= $id_k; ?>"><?= htmlspecialchars($nama_k); ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="col-md-3 form-group">
                                <label>Tahun Ajaran</label>
                                <input type="text" name="tahun_ajaran" class="form-control" value="2026/2027" required>
                            </div>
                            <div class="col-md-1 form-group d-flex align-items-end">
                                <button type="submit" name="tambah_penempatan" class="btn btn-success btn-block font-weight-bold"><i class="fas fa-save"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <?php endif; ?>

            <!-- Tabel Data Penempatan -->
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="tabelPenempatan" class="table table-bordered table-striped table-hover align-middle mb-0" style="width:100%;">
                            <thead class="thead-dark text-center">
                                <tr>
                                    <th width="50">No</th>
                                    <th>ID / Info Siswa</th>
                                    <th>ID / Info Kelas</th>
                                    <th>Tahun Ajaran</th>
                                    <?php if (strtolower($_SESSION['role'] ?? '') === 'admin'): ?>
                                        <th width="100">Aksi</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $no = 1;
                                if ($query_data && mysqli_num_rows($query_data) > 0) {
                                    while ($row = mysqli_fetch_assoc($query_data)) {
                                        $id_p = $row['id'] ?? $row['id_siswa_kelas'] ?? 0;
                                        $id_s_val = $row['id_siswa'] ?? 0;
                                        $id_k_val = $row['id_kelas'] ?? 0;
                                        $thn = $row['tahun_ajaran'] ?? '2026/2027';
                                ?>
                                    <tr>
                                        <td class="text-center"><?= $no++; ?></td>
                                        <td>Siswa ID: <strong><?= $id_s_val; ?></strong></td>
                                        <td>Kelas ID: <strong><?= $id_k_val; ?></strong></td>
                                        <td class="text-center"><?= htmlspecialchars($thn); ?></td>
                                        <?php if (strtolower($_SESSION['role'] ?? '') === 'admin'): ?>
                                            <td class="text-center">
                                                <a href="siswa_kelas.php?action=hapus&id=<?= $id_p; ?>" class="btn btn-danger btn-sm" title="Hapus" onclick="return confirm('Hapus penempatan ini?')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php 
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </section>
</div>

<!-- SCRIPT JQUERY & DATATABLES -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
<script>
    $(document).ready(function() {
        $('#tabelPenempatan').DataTable({
            "language": {
                "search": "Cari:",
                "lengthMenu": "Tampilkan _MENU_ data",
                "zeroRecords": "Tidak ada data penempatan",
                "info": "Halaman _PAGE_ dari _PAGES_",
                "paginate": {
                    "first": "Pertama",
                    "last": "Terakhir",
                    "next": "Selanjutnya",
                    "previous": "Sebelumnya"
                }
            }
        });
    });
</script>

<?php include 'footer.php'; ?>