<?php
require_once 'auth.php';
require_once 'koneksi.php';

include 'header.php';
?>

<h2>Dashboard Utama</h2>
<p>Selamat datang di Sistem Pelanggaran Siswa.</p>

<h3>Menu Utama</h3>
<ul>
    <li><a href="siswa.php">Kelola Siswa</a></li>
    <li><a href="guru.php">Kelola Guru</a></li>
    <li><a href="kelas.php">Kelola Kelas</a></li>
    <li><a href="kelas_siswa.php">Penempatan Siswa</a></li>
    <li><a href="wali_kelas.php">Wali Kelas</a></li>
    <li><a href="pelanggaran_kategori.php">Pelanggaran Kategori</a></li>
    <li><a href="pelanggaran.php">Master Pelanggaran</a></li>
    <li><a href="rekap_poin.php">Rekap Poin</a></li>
    <li><a href="riwayat_pelanggaran.php">Riwayat Pelanggaran</a></li>
    <li><a href="laporan.php">Laporan</a></li>
    <li><a href="logout.php">Logout</a></li>
</ul>

<?php include 'footer.php'; ?>